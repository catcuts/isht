/*　China Fujian Huanyutong Technology Co., Ltd. */
process.env.NODE_PATH=__dirname,require("module").Module._initPaths();const vigserver=require("./server");vigserver.start();