/*　China Fujian Huanyutong Technology Co., Ltd. */
async function sleep(e){var l=null;let n=new Promise((e,n)=>{l=e});return setTimeout(()=>{l()},e),n}module.exports=sleep;