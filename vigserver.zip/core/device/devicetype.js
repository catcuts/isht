/* www.huanyutong.com */
const DeviceProxyBase = require("./deviceproxy").DeviceProxyBase,
    {
        VIGModule: VIGModule
    } = require("core/vigmodule"),
    Notifys = require("core/eventbus/notifys"),
    {
        diffJsonItems: diffJsonItems
    } = require("utils/jsonfuncs"),
    {
        MessageTypes: MessageTypes,
        DeviceEventCodes: DeviceEventCodes,
        MessageAnswer: MessageAnswer
    } = require("core/protocols/vimp/constants"),
    VIMPAlarms = require("core/protocols/vimp/alarmdef"),
    {
        setMessageFlags: setMessageFlags
    } = require("services/vmc/utils"),
    util = require("util"),
    SessionTimeOutError = require("utils/session").SessionTimeoutError,
    VIMPMessages = require("core/protocols/vimp/message"),
    VIMPErrors = require("core/protocols/vimp/errors"),
    {
        extractJsonItems: extractJsonItems,
        filterJsonByKeys: filterJsonByKeys,
        cloneJson: cloneJson
    } = require("utils/jsonfuncs"),
    {
        triggerEventTransaction: triggerEventTransaction
    } = require("core/transactions"),
    {
        EventThrottler: EventThrottler
    } = require("core/device/throttler"),
    deepMerge = require("deep-extend"),
    dayjs = require("dayjs"),
    {
        MapArrayDeviceAttr: MapArrayDeviceAttr
    } = require("./deviceattr");

function diffAttrsMessage(e, t) {
    let r = {};
    for (let s in t) s in e && t[s] !== e[s] && (r[s] = {
        value: t[s],
        oldValue: e[s]
    });
    return r
}
const defaultReservedAttrs = ["_id", "meta", "advanced", "entry", "behavior", "services"];
class DeviceTypeBase extends VIGModule {
    constructor(e, t) {
        super(e, t), this.__VIG_DEVICETYPE__ = !0, this.storageName = "devicetypes", this.storagePrimaryKey = "name", this.moduleType = "devicetype", this.devices = {}
    }
    get inPort() {}
    get outPort() {
        return this.vmc
    }
    get advancedSettings() {
        return this.attrs.advanced || {}
    }
    get ruleEngine() {
        return this._ruleEngine || (this._ruleEngine = VIGServices.getServices("ruleengine")), this._ruleEngine
    }
    updateStatus(e, t, r) {
        VIGDevices.updateDeviceStatus(e, t, r)
    }
    appendToDevices(e) {
        e.sn in this.devices || (this.devices[e.sn] = e)
    }
    setAttrs(e) {
        super.setAttrs(e), this.attrs.advanced = deepMerge({
            connectBehavior: 2,
            msgHandleBehavior: 0,
            readOnlyAttrs: ["sn", "version", "authorized"],
            syncAttrs: [],
            softSyncAttrs: [],
            allowAddAttrs: [],
            allowDeleteAttrs: [],
            eventThrottle: {
                enabled: !0,
                excludes: [],
                interval: 0
            },
            transaction: {
                events: [],
                alarms: []
            },
            reservedAttrs: [],
            dateTimeFormat: "YYYYMMDDHHmmss"
        }, e.advanced || {}), this.attrs.meta = deepMerge({
            attrs: {
                sn: {
                    title: _("SerialNo"),
                    valuetype: "string",
                    readOnly: !0
                },
                name: {
                    title: _("Name"),
                    valuetype: "string"
                },
                models: {
                    title: _("Models"),
                    valuetype: "string"
                },
                enabled: {
                    valuetype: "boolean",
                    default: !0
                },
                authorized: {
                    valuetype: "boolean"
                },
                version: {
                    valuetype: "string"
                }
            }
        }, e.meta || {}), this.attrs.advanced.reservedAttrs = this.attrs.advanced.reservedAttrs.concat(defaultReservedAttrs)
    }
    async loadRemainDevices() {
        try {
            let e = await this.devicesStorage.find({
                type: this.name,
                enabled: !0,
                remain: !0
            });
            for (let t of e) {
                let e = await this.getDeviceProxy(t, !0, this);
                this.appendToDevices(e)
            }
        } catch (e) {
            logger.error(_("Error while load remain devices:{error}").params(e.stack))
        }
    }
    async init() {
        this.devicesStorage = await VIGStorage.getDocument("devices"), await this.loadRemainDevices()
    }
    filterSyncAttrs(e = {}) {
        let t = this.advancedSettings.syncAttrs || [],
            r = this.advancedSettings.softSyncAttrs || [];
        if (Array.isArray(t) || (t = [t]), Array.isArray(r) || (r = [r]), Array.isArray(e)) {
            let s = [
                [],
                [],
                []
            ];
            for (let r of t) e.includes(r) && s[0].push(r);
            for (let t of r) e.includes(t) && s[1].push(t);
            for (let t of e) s[0].includes(t) && s[1].includes(t) && s[2].push(t);
            return s
        }
        if ("object" == typeof e) {
            let s = [{}, {}, {}];
            for (let r of t) r in e && (s[0][r] = e[r]);
            for (let t of r) t in e && (s[1][t] = e[t]);
            return s[2] = filterJsonByKeys(e, [...Object.keys(s[0]), ...Object.keys(s[1])], !0), s
        }
    }
    async syncAttrsToDevice(e, t = {}) {
        let r = {},
            s = {},
            [a, i] = this.verifyAttrValue(t),
            n = {},
            [o, l, c] = this.filterSyncAttrs(a);
        if (Object.keys(o).length > 0) try {
            (await this.sendMessageToDevice(VIMPMessages.Attrs({
                to: e,
                flags: {
                    receipt: !0
                },
                attrs: {
                    _batch_: !0,
                    ...o
                }
            }), !0)).payload.code === MessageAnswer.OK && (n = await this.saveAttrsToStorage(e, o), Object.assign(r, n))
        } catch (e) {
            logger.error(_("Error while sync attrs({attrs}) to device:{err}").params(JSON.stringify(o), e.message)), Object.assign(s, o), s._error = e.message
        }
        if (Object.keys(l).length > 0) try {
            n = await this.saveAttrsToStorage(e, l), (await this.sendMessageToDevice(VIMPMessages.Attrs({
                to: e,
                flags: {
                    receipt: !0
                },
                attrs: {
                    _batch_: !0,
                    ...l
                }
            }), !0)).payload.code === MessageAnswer.OK ? Object.assign(r, n) : Object.assign(s, l)
        } catch (e) {
            logger.error(_("Error while sync attrs({attrs}) to device:{err}").params(JSON.stringify(l), e.message)), Object.assign(s, l), s._error = e.message
        }
        if (Object.keys(c).length > 0) try {
            n = await this.saveAttrsToStorage(e, c), Object.assign(r, n)
        } catch (e) {
            logger.error(_("Error while save attrs to storage:{err}").params(e.message)), Object.assign(s, c), s._error = e.message
        }
        return [r, s, i]
    }
    get meta() {
        return this.attrs.meta || {}
    }
    isValidAttr(e) {
        return e in this.meta.attrs
    }
    getAttrMeta(e) {
        let t = Object.assign({
            title: "",
            valuetype: "string",
            choices: [],
            readOnly: !1,
            default: null,
            help: "",
            validator: null
        }, this.meta.attrs[e] || {});
        return this.isValidAttr(e) ? t : null
    }
    filterValidAttrs(e) {
        let t = {},
            r = {},
            s = {};
        for (let a in e)
            if (a in this.meta.attrs) {
                let i = this.getAttrMeta(a);
                i ? "devices" === i.storage || void 0 === i.storage ? t[a] = e[a] : r[i.storage] = {
                    [a]: e[a]
                } : s[a] = e[a]
            } else s[a] = e[a];
        return [t, r, s]
    }
    async saveAttrToExternalStorage(e, t, r, s) {
        if (void 0 === s && (s = this.getAttrMeta(e)), "map-array" === s.valuetype) {
            let e = new MapArrayDeviceAttr(s.storage);
            return await e.update(r, {
                $set: t
            }, {
                returnUpdatedDocs: !0
            })
        }
        throw new VIMPErrors.FailError(_("Do not support update attr <name>").params(e))
    }
    async saveAttrsToStorage(e, t) {
        if (0 === Object.keys(t).length) return {};
        let r = {},
            [s, a] = this.filterValidAttrs(t);
        if (0 !== Object.keys(s).length || 0 !== Object.keys(a).length) {
            if (Object.keys(s).length > 0 && (await VIGDevices.saveDeviceToStorage({
                    sn: e,
                    ...s
                }), Object.assign(r, s), await this.renewRemainDeviceProxy(e)), Object.keys(a).length > 0) {
                let e = [];
                for (let t in a) {
                    let s = a[t];
                    for (let t in s) {
                        let a = s[t];
                        try {
                            e = await this.saveAttrToExternalStorage(a.name, a.value, a.query), r[t] = {
                                updated: e.map(e => e._id)
                            }
                        } catch (e) {
                            throw new VIMPErrors.FailError(_("Fail while updating <{name}> attr.".params(t.name, e.message)))
                        }
                    }
                }
            }
            return r
        }
        logger.warn(_("Unable save attrs to storage:{attrs}").params(JSON.stringify(t)))
    }
    async deleteDeviceAttrs(e, t) {
        "string" == typeof t ? t = t.split(",") : Array.isArray(t) || (t = [t]);
        let r = {};
        for (let e of t) r[e] = !0;
        let s = await this.devicesStorage.update({
            sn: e
        }, {
            $unset: { ...r
            }
        });
        return await this.renewRemainDeviceProxy(e), s
    }
    async getDeviceAttrsFromStorage(e) {
        return await this.devicesStorage.findOne({
            sn: e
        })
    }
    async renewRemainDeviceProxy(e) {
        try {
            let t = await this.getDeviceProxy(e);
            t && await t.reload()
        } catch (t) {
            logger.warn(_("Error while renew remain deviceproxy <{sn}>:{error}").params(e, t.stack))
        }
    }
    publishNotify(e, t = {}) {
        let r = "devicetype." + this.name.toLowerCase();
        e === Notifys.DeviceAttrsChange ? r += ".attrs" : e === Notifys.DeviceStatusChange ? r += ".status" : e === Notifys.DeviceChildrenAuthorize && (r += ".children"), this.node.publish(r, t)
    }
    publishEvent(e = {}) {
        this.node.publish("devicetype." + this.name.toLowerCase() + ".events", e)
    }
    publishAlarm(e = {}) {
        this.node.publish("devicetype." + this.name.toLowerCase() + ".alarms", e)
    }
    async addDeviceAttr(e, t) {
        if (t.operate = this.advancedSettings.allowAddAttrs.includes(t.name)) return await this.saveAttrsToStorage(e, {
            [t.name]: t.value
        });
        throw new VIMPErrors.DeniedError
    }
    isEnableRuleEngine(e) {
        return !0
    }
    getArrayAttrMaxLength(e) {
        return 100
    }
    onAfterAttrsUpdate(e, t) {}
    verifyAttrValue(e) {
        return [cloneJson(e), {}]
    }
    async getAttrValue(e, t = "") {
        return (await this.devicesStorage.findOne({
            sn: e
        }))[t]
    }
    async updateBatchAttrs(e, t) {
        if (0 === Object.keys(t).length) throw new VIMPErrors.ParamError(_("No parameters"));
        let [r, s, a] = this.filterValidAttrs(t), i = {};
        if (0 === Object.keys(r).length) throw new VIMPErrors.FailError(_("Invalid attributes:{error}").params(Object.keys(t).join(","))); {
            let t = await this.getDeviceAttrsFromStorage(e),
                n = diffJsonItems(t, r, !1);
            if (0 === Object.keys(n).length) {
                if (logger.warn(_("Attributes has no change, no updated.")), Object.keys(s).length > 0) throw new VIMPErrors.ParamError(_("Cannot be updating attrs <{attrs}> in a batch way").params(Object.keys(s).join(",")));
                if (Object.keys(a).length > 0) throw new VIMPErrors.ParamError(_("Invalid attrs:{attrs}").params(Object.keys(a).join(",")))
            } else {
                let [t, r] = await this.syncAttrsToDevice(e, n);
                if (Object.assign(i, t), 0 === Object.keys(t).length) throw new VIMPErrors.FailError("Update fail:", Object.assign(r, a))
            }
            return i
        }
    }
    async updateSingleAttr(e, t) {
        let r = t.name,
            s = {},
            a = {},
            i = this.getAttrMeta(r);
        if (null === i) throw new VIMPErrors.ParamError(_("Invalid device attr <{attr}>").params(r));
        if (void 0 === r || void 0 === t.value) throw new VIMPErrors.ParamError(_("Lost name parameter"));
        if (this.advancedSettings.readOnlyAttrs.includes(r)) throw new VIMPErrors.DeniedError(_("Read-only attribute"));
        if (i.storage && "devices" !== i.storage) s = {
            [r]: {
                name: r,
                value: t.value,
                query: t.for
            }
        };
        else if (a = await this.getAttrValue(e, r, i.storage), Array.isArray(a)) {
            let e = parseInt(t.for);
            if (e)
                if (e < a.length) a[e] = t.value, s = {
                    [r]: a
                };
                else {
                    if (!(e < this.getArrayAttrMaxLength(r))) throw new VIMPErrors.FailError(_("Invalid array index"));
                    a.push(t.value), s = {
                        [r]: a
                    }
                }
            else {
                if (!Array.isArray(t.value)) throw new VIMPErrors.ParamError(_("Invalid <for> parameter"));
                s = {
                    [r]: t.value
                }
            }
        } else if (util.isObject(a)) {
            let e = String(t.for);
            if (e && "string" == typeof e && e in a) s = {
                [r]: Object.assign(a, {
                    [e]: t.value
                })
            };
            else {
                if ("object" != typeof t.value) throw new VIMPErrors.ParamError(_("Invalid <for> parameter"));
                s = {
                    [r]: t.value
                }
            }
        } else a === t.value || void 0 !== a && typeof a != typeof t.value || (s = {
            [r]: t.value
        });
        if (Object.keys(s).length > 0) {
            let [t, r, a] = await this.syncAttrsToDevice(e, s);
            if (Object.keys(a).length > 0) throw new VIMPErrors.FailError(a._error || _("Invalid attr value:{attrs}").params(Object.keys(a).join(",")));
            if (Object.keys(r).length > 0) throw new VIMPErrors.FailError(r._error || _("Update fail:{attrs}").params(Object.keys(r).join(",")));
            return t
        }
        throw new VIMPErrors.FailError(_("Attribute {name} is not updated").params(r))
    }
    onUnload() {}
    getProxyClass() {
        return DeviceProxyBase
    }
    async getDeviceProxy(e, t = !1) {
        if (e in this.devices) return this.devices[e];
        if (t) {
            let t = new(this.getProxyClass())("string" == typeof e ? e : e.sn, this);
            return "string" == typeof attrsOrSn ? await t.load() : t.from(e), t
        }
    }
    noticeUpdateDeviceAttrs(e = "", t = {}) {
        this.onMessage(VIMPMessages.Attrs({
            to: e,
            flags: {
                receipt: !1
            },
            type: MessageTypes.Attrs,
            payload: {
                _batch_: !0,
                ...t
            }
        }))
    }
    async _UpdateAttrsOperate(e) {
        let t = e.to,
            r = {};
        return "_batch_" in e.payload ? (delete e.payload._batch_, r = await this.updateBatchAttrs(t, e.payload)) : r = await this.updateSingleAttr(t, e.payload), this.publishNotify(Notifys.DeviceAttrsChange, {
            sn: t,
            attrs: r
        }), Object.keys(r).length > 0 && await this.onAfterAttrsUpdate(r), r
    }
    async _AddAttrsOperate(e) {
        return await this.addDeviceAttr(e.to, e.payload)
    }
    async _DeleteAttrsOperate(e) {}
    async onAttrsMessage(e) {
        let t = "",
            r = {};
        if ("number" == typeof e.payload.operate) {
            let r = parseInt(e.payload.operate);
            t = ["update", "delete", "add"][r > 2 || r < 0 ? e.payload.operate : 0]
        } else t = e.payload.operate || "update";
        return "update" === t ? r = await this._UpdateAttrsOperate(e) : "add" === t ? r = await this._AddAttrsOperate(e) : "delete" === t && (r = await this._DeleteAttrsOperate(e)), Object.keys(r).length > 0 ? [VIMPMessages.AttrsChangeEvent({
            attrs: r
        }), VIMPMessages.Answer({
            payload: {
                updated: Object.keys(r)
            }
        })] : VIMPMessages.Answer({
            message: _("Attrs has no updated")
        })
    }
    async onEventMessage(e) {
        let t = EventThrottler(e, this.advancedSettings.eventThrottle || {});
        if (null !== t) {
            if (triggerEventTransaction(t, this.advancedSettings.transaction || {}), this.isEnableRuleEngine()) try {
                this.ruleEngine.execute(t, {
                    Event: t.payload
                }), setMessageFlags(t, {
                    reply: !0
                })
            } catch (e) {
                logger.warn(_("Error while execute rule for message of event :{error}").params(e.message))
            }
            return this.publishEvent(t), VIMPMessages.Event(t)
        }
    }
    async onAnswerMessage(e) {}
    async onAlarmMessage(e) {
        return this.publishAlarm(e.payload), VIMPMessages.Alarm(e)
    }
    async queryExtDeviceAttrs(e, t, r) {
        let s = new MapArrayDeviceAttr(e || t);
        return result = await s.find(r), result
    }
    isExtDeviceAttr(e) {
        let t = this.getAttrMeta(e);
        return !!t && (void 0 !== t.storage && ("devices" !== t.storage && "map-array" === t.valuetype))
    }
    async queryDeviceAttrs(e) {
        let t = {},
            r = e.payload.fields,
            s = await VIGDevices.findOne({
                sn: e.to
            });
        if (1 === r.length && "*" === r[0]) t = filterJsonByKeys(s, this.advancedSettings.reservedAttrs, !0);
        else if (1 === r.length) {
            let a = e.payload.query || {},
                i = this.getAttrMeta(r[0]);
            t = this.isExtDeviceAttr(r[0]) ? await this.queryExtDeviceAttrs(i, r[0], a) : {
                [r[0]]: s[r[0]] || i.default
            }
        } else t = r.length > 1 ? extractJsonItems(s, r) : extractJsonItems(s, ["sn", "name", "type", "models", "datetime", "debug", "language", "domain", "timeZone", "charset", "group", "authorized", "enabled"]);
        return t
    }
    async queryDeviceStatus(e) {
        if (e.to in this.devices) {
            let t = this.devices[e.to].status,
                r = {},
                s = e.payload.fields || [];
            return r = Array.isArray(s) && s.length > 0 ? extractJsonItems(t, s) : t
        }
        throw new VIMPErrors.FailError(_("Invalid serialNo:{}").params(e.to))
    }
    queryDeviceActions(e) {}
    async queryDeviceChildren(e) {
        if ("vigateway" === this.name) {
            let t = {
                    $and: [{
                        type: {
                            $ne: "vigateway"
                        }
                    }, {
                        $or: [{
                            parent: this.host.sn
                        }, {
                            parent: ""
                        }, {
                            parent: {
                                $exists: !1
                            }
                        }]
                    }]
                },
                r = await VIGDevices.find(t),
                s = [],
                a = e.payload.flags;
            return {
                children: s = 0 === a.format ? r.map(e => e.sn) : 1 === a.format ? r.map(e => extractJsonItems(e, ["name", "sn", "type", "models", "domain", "enabled", "authorized"])) : r.map(e => filterJsonByKeys(e, ["_id"], !0))
            }
        }
        throw new VIMPErrors.ParamError(_("Unsupported operations"))
    }
    async onQueryMessage(e) {
        let t = (e.payload.type || "").toLowerCase(),
            r = e.payload.fields || [];
        if ("string" == typeof r) r = r.includes(",") ? r.splice(",") : [r];
        else if (!Array.isArray(r)) throw VIMPErrors.ParamError(_("lose <fields> parameter"));
        e.payload.fields = r, e.payload.flags = Object.assign({
            format: 1,
            support: !1,
            forceSync: !1
        }, e.payload.flags || {});
        let s = {};
        try {
            switch (t) {
                case "attrs":
                    s = await this.queryDeviceAttrs(e);
                    break;
                case "status":
                    s = await this.queryDeviceStatus(e);
                    break;
                case "children":
                    s = await this.queryDeviceChildren(e);
                    break;
                case "meta":
                    break;
                default:
                    throw new VIMPErrors.FailError(_("Invalid query type:{type}").params(t))
            }
            return VIMPMessages.Answer({
                payload: {
                    result: s
                }
            })
        } catch (e) {
            throw new VIMPErrors.FailError(_("Failure to query:{error}").params(e.message))
        }
    }
    async onActionMessage(e) {
        let t = "";
        if (!("action" in e.payload)) throw new VIMPErrors.ParamError("lost <action> parameters");
        try {
            let r = "onAction" + (t = e.payload.action.toLowerCase()).firstUpper();
            if ("" !== t && r in this) return await this[r](e); {
                let e = _("Not supported action <{name}>.").params(t);
                throw new VIMPErrors.RejectError(e)
            }
        } catch (e) {
            throw logger.error(_("Error while execute action {name}:{error}").params(t, e.stack)), new VIMPErrors.FailError(e.message)
        }
    }
    async onActionPing(e) {
        return VIMPMessages.Answer({
            code: MessageAnswer.OK
        })
    }
    async onActionAuthorize(e) {
        let t = e.to;
        if (VIGDevices.exists(t)) {
            let r = Boolean(e.payload.authorized),
                s = void 0 === e.payload.name ? t : e.payload.name;
            return await this.authorize(t, s, r), this.publishNotify(Notifys.DeviceChildrenAuthorize, {
                sn: t,
                authorized: r
            }), VIMPMessages.Event({
                payload: {
                    code: DeviceEventCodes.DeviceAuth,
                    authorized: !0 === r ? 1 : 2,
                    source: t
                }
            })
        }
        throw new VIMPErrors.FailError(_("Device <{sn}> no exists.").params(t))
    }
    async authorize(e, t, r = !0) {
        return (await this.sendMessageToDevice(VIMPMessages.Action({
            to: e,
            flags: {
                receipt: !0
            },
            payload: {
                action: "authorize",
                flags: {},
                authorized: r,
                name: t,
                datetime: dayjs().format(this.advancedSettings.dateTimeFormat)
            }
        }), !0)).payload.code === MessageAnswer.OK && (await this.saveAttrsToStorage(e, {
            authorized: r,
            authTime: new Date
        }), logger.debug(_("Device <{sn}> authorize success").params(e)), !0)
    }
    async onNotifyMessage(e) {}
    async onMessageMessage(e) {}
    async onDataMessage(e) {}
    isValidMessage(e) {
        let t = [MessageTypes.Answer, MessageTypes.Register, MessageTypes.Event, MessageTypes.Alarm].includes(e.type) ? e.from : e.to;
        return !!VIGDevices.exists(t) || ("" === t || "FFFFFFFF" === t || "*" === t || e.type === MessageTypes.Register)
    }
    async sendMessageToDevice(e, t = !1) {
        if (t) {
            setMessageFlags(e, {
                receipt: !0
            });
            let t = null,
                r = e.to,
                s = this.inPort.createSession(r);
            try {
                if (t = await s.send(e), s.end(), null === t) throw new VIMPErrors.UnknowError(_("Get invalid answer while send message to device<{sn}>:{message}").params(r, JSON.stringify(e)));
                if (VIMPErrors.isError(t)) throw new(VIMPErrors.getError(t.payload.code));
                return t
            } catch (e) {
                throw s.end(), e instanceof SessionTimeOutError ? (logger.debug(_("Timeout while send message to device:{err}").params(e.message)), new SessionTimeOutError(_("Timeout while send message to device"))) : Error(_("Error while send message to device:{err}").params(e.message))
            }
        } else setMessageFlags(e, {
            receipt: !1
        }), this.inPort.sendToDevice(e)
    }
    async onRegisterMessage(e) {
        logger.debug(_("Wireless device <{sn}> is being register.").params(e.from));
        let t = e.payload;
        t.sn = e.from, t.parent = "";
        let r = await VIGDevices.findOne({
            sn: e.from,
            type: t.type
        });
        if (!r) return t.authorized = !1, t.registerDate = new Date, r = await VIGDevices.addDevice(t), VIMPMessages.Event({
            code: DeviceEventCodes.DeviceAuth,
            location: r.location || {},
            payload: {
                authorized: 0,
                source: r.sn,
                models: r.models,
                name: r.name,
                type: r.type
            }
        });
        try {
            let e = await this.authorize(r.sn, r.name, void 0 === r.authorized || r.authorized);
            return VIMPMessages.Event({
                code: DeviceEventCodes.DeviceAuth,
                payload: {
                    authorized: !0 === e ? 1 : 2,
                    source: r.sn,
                    models: r.models,
                    name: r.name,
                    type: r.type
                }
            })
        } catch (e) {
            logger.warn(_("Error while authorize devie<{sn}>:{err}").params(t.sn, e.message))
        }
    }
    triggerEvent(e) {
        this.outPort.send(e)
    }
    triggerAlarm(e) {
        this.outPort.send(e)
    }
    onMessage(e) {
        if (!this.isValidMessage(e)) return void logger.debug(_("The devicetype <{name}> receives an invalid message:{message}").params(this.name, JSON.stringify(e)));
        let t = null;
        try {
            t = [this.onRegisterMessage, this.onNotifyMessage, this.onAttrsMessage, "", this.onActionMessage, this.onAlarmMessage, this.onEventMessage, this.onMessageMessage, this.onDataMessage, this.onQueryMessage, "", this.onAnswerMessage][e.type].bind(this)
        } catch (t) {
            logger.debug(_("Invalid vimp message type:{msg}").params(e))
        }
        t(e).then(t => {
            let r = !1;
            if (t) {
                Array.isArray(t) || (t = [t]);
                for (let s of t) "object" == typeof s ? (s.sid = e.sid, s.to = s.type === MessageTypes.Answer ? e.from : s.to, (s.type !== MessageTypes.Answer || s.type === MessageTypes.Answer && e.flags.receipt) && this.outPort.send(s, !1), !1 === r && s.type === MessageTypes.Answer && (r = !0)) : logger.warn("Invalid vimp message:{msg}".params(String(s)));
                r && 0 !== t.length || !e.flags.receipt || this.outPort.send(VIMPMessages.Answer({}), !1)
            }
        }).catch(t => {
            if (e.type === MessageTypes.Register) this.outPort.send(VIMPMessages.Alarm({
                code: VIMPAlarms.RegisterFail[0],
                source: e.from,
                message: t.message,
                level: VIMPAlarms.RegisterFail[1]
            }), !1);
            else {
                let r = {
                    sid: e.sid,
                    to: e.from
                };
                t instanceof VIMPErrors.VIMPError ? Object.assign(r, {
                    code: t.code,
                    message: t.message,
                    payload: t.params || {}
                }) : Object.assign(r, {
                    code: MessageAnswer.Fail,
                    message: t.message
                }), e.type !== MessageTypes.Answer && e.flags.receipt && this.outPort.send(VIMPMessages.Answer(r, !1))
            }
        })
    }
    onHostEvents(e) {}
}
module.exports = {
    DeviceTypeBase: DeviceTypeBase
};