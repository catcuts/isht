/*　China Fujian Huanyutong Technology Co., Ltd. */
const{Platform:Platform}=require("./platform");class OrangePi extends Platform{}module.exports=OrangePi;