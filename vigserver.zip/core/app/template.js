/*　China Fujian Huanyutong Technology Co., Ltd. */
const fs=require("fs");let render=function(e,r){return{__TEMPLATE__:!0,template:e,context:r}};module.exports=render;