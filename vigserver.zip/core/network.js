/*　China Fujian Huanyutong Technology Co., Ltd. */
class NetworkManager{constructor(){}configure(e){}get ip(){}get dns(){}get gateway(){}get subnetMask(){}}