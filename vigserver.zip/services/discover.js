/*　China Fujian Huanyutong Technology Co., Ltd. */
const ServiceBase=require("../core/service/servicebase");class DiscoverService extends ServiceBase{start(){}}module.exports=DiscoverService;