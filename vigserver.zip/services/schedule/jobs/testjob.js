/*　China Fujian Huanyutong Technology Co., Ltd. */
module.exports={cronTime:"05 30 11 * * 1-5",onTick:function(){console.log("Run schedule test job")}};