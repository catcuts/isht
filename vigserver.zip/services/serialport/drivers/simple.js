/*　China Fujian Huanyutong Technology Co., Ltd. */
const SerialportDriverBase=require("./base");class SimpleSerialportDriver extends SerialportDriverBase{}module.exports=SimpleSerialportDriver;