  
 网关属性说明
 
  
  name:
  
    # 初始化加载时，将__host__替代为当前网关设备的SN
    sn: __host__
    title: 物联网无线网关
    language:
    domain: 0
    debug: true
    # 是否在启动后加载此设备实例
    remain: true
    enabled: true
    # 设备所有者
    owner:
    # 设备客户名称
    customer:
    #该设备所属部门
    dept:
    description:
    version: 1.0
    #工作模式，取值0=联网协作模式,默认连接到MQTT；1=独立模式,不连接到MQTT
    mode: 0
    #消息处理行为
    #0-自动，如果工作在独立模式下总是规则引擎处理，在联网模式下，先发送给服务器，如果服务器未连接，则由规则引擎处理
    #1-本地规则引擎进行处理 ,2- 总是转发至服务器进行处理
    behavior: 0
    #是否支持无线漫游0:默认,不支持漫游；1：组播漫游，2：云端漫游
    roaming: 0
    #漫游编号
    roamingGroup: 0
    #漫游域，当云端漫游时使用来标识漫游
    roamingDomain:
    type: VIGateway
    # 所在时区
    timeZone: Asia/Shanghai
    # 型号
    models: VIG9002
    # 安全密钥
    secret: 5cd29c05899347deb711a45f875f65ba
    # Web服务器侦听端口
    port: 80
    #VIG设备所在的地理位置,经度、纬度、高程
    location:
      longitude:
      latitude:
      altitude:
    # 新发现的设备自动激活,False时会将发现的设备上报给服务器
    # true : 自动加入到设备清单中
    autoDiscover: true
    #设备分组路径，如果没有指定则默 认是/o
    group:
    # 设备事务参数
    transaction:
      # 事务超时处理时间，以分钟为单位
      timeout: 60
      #保留事务长度,0-默认1000条,
      maxLength: 0
      # 已完成事务保留时间，0-不保留
      dataKeepTime: 0


    # 设备网络地址配置
    network:
      # 默认有线网络
      default:
        title: 默认网络
        enabled: true
        dns: auto
        dhcp: false
        ip: 192.168.0.1
        subnetMask: 255.255.255.0
        gateway: 0.0.0.0
      wifi:
        title: 无线网络
        enabled: false
        password:
        dns: auto
        dhcp: false
        ip: 192.168.0.1
        subnetMask: 255.255.255.0
        gateway: 0.0.0.0
    # 设备作为无线AP使用
    ap:
      enabled: false
      name: MeeYiAP
      password:
    # 内置DHCP服务器配置
    dhcp:
      enabled: false
      range:
    #缓存管理，允许创建多个缓存
    caches:
      - name: devicestatus
        title:
        description: Managing device state caching
        enabled: true
    # 日志配置
    logger:
      level: DEBUG
      # 日志输出目标设置，如果要输出到logServer需加入server
      output: console,file
      # 日志文件最大尺寸
      fileSize:
      # 日志文件备份数量，默认3
      fileCount: 3
      # 日志服务器地址,默认使用UDP协议,如udp://192.168.1.1
      server:
    # 消息总线
    eventbus:
      # 脉搏信号,默认每2秒产生一个信号,0-不产生
      pulse: 2000
    # 连接到MQTT Broker的配置参数
    mqtt:
      broker: mqtt://127.0.0.1
      username:
      password:
      strict: false