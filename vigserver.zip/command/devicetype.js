/*　China Fujian Huanyutong Technology Co., Ltd. */
function devicetype(e,o){console.log("Cmd=",e),console.log("list=",o.list)}module.exports=devicetype;