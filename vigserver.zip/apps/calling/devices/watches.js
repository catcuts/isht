/*　China Fujian Huanyutong Technology Co., Ltd. */
const WirelessDeviceType=require("./base");class Watches extends WirelessDeviceType{}module.exports=Watches;