/*　China Fujian Huanyutong Technology Co., Ltd. */
const WirelessDeviceType=require("./base");class Callkeyboard extends WirelessDeviceType{}module.exports=Callkeyboard;