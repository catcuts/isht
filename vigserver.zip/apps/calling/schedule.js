/*　China Fujian Huanyutong Technology Co., Ltd. */
const job1={cronTime:"",onTick:function(){}};module.exports=[];