/*　China Fujian Huanyutong Technology Co., Ltd. */
class SettingsApi extends ApiBase{get(e,s){}}