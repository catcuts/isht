/*　China Fujian Huanyutong Technology Co., Ltd. */
const Template=require("core/app/template");function index(e,t,n){return Template("index.art",{HYT:"环宇通"})}module.exports=index;