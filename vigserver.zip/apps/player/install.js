/*　China Fujian Huanyutong Technology Co., Ltd. */
module.exports={install:function(n){},uninstall:function(n){}};